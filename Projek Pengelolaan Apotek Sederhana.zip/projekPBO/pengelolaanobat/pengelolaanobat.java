import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class pengelolaanobat {
    private static Connection conn;

    public static void initConnection() {
        try {
            String url = "jdbc:mysql://localhost:3306/pengelolaan_apotek"; // Ganti dengan nama database
            String user = "root"; // Ganti dengan username database
            String password = ""; // Ganti dengan password database
            conn = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Koneksi ke database gagal: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        initConnection();
        openLoginFrame();
    }

    // Method to validate login credentials from database
    public static boolean validateLogin(String username, String password) {
        try {
            // Connect to MySQL database
            String url = "jdbc:mysql://localhost:3306/pengelolaan_apotek";  // Ganti dengan nama database Anda
            String user = "root";  // Ganti dengan username MySQL Anda
            String pass = "";  // Ganti dengan password MySQL Anda

            // Create connection
            Connection conn = DriverManager.getConnection(url, user, pass);
            String query = "SELECT * FROM admin WHERE username = ? AND password = ?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, username);
            pst.setString(2, password);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                return true;  // Login berhasil
            } else {
                return false;  // Login gagal
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;  // Jika terjadi error saat koneksi
        }
    }

    public static void openLoginFrame() {
        // Frame Login
        JFrame loginFrame = new JFrame("Login - Aplikasi Pengelolaan Obat");
        loginFrame.setSize(400, 600);
        loginFrame.getContentPane().setBackground(Color.decode("#388dff"));
        loginFrame.setLayout(null);
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
        // Logo
        ImageIcon logoIcon = new ImageIcon("D:\\projekPBO\\pengelolaanobat\\apotek_logoo.png");
        Image logoImage = logoIcon.getImage();
        Image scaledLogo = logoImage.getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        logoIcon = new ImageIcon(scaledLogo);
        JLabel logoLabel = new JLabel(logoIcon);
        logoLabel.setBounds(150, 30, 100, 100);
        loginFrame.add(logoLabel);
    
        // Title
        JLabel title1 = new JLabel("APLIKASI PENGELOLAAN");
        title1.setBounds(80, 140, 300, 30);
        title1.setFont(new Font("Arial", Font.BOLD, 18));
        title1.setForeground(Color.WHITE);
        loginFrame.add(title1);
    
        JLabel title2 = new JLabel("DATA APOTEK");
        title2.setBounds(130, 170, 150, 30);
        title2.setFont(new Font("Arial", Font.BOLD, 18));
        title2.setForeground(Color.WHITE);
        loginFrame.add(title2);
    
        // Username and Password Labels and Fields
        JLabel usernameLabel = new JLabel("Username");
        usernameLabel.setBounds(50, 230, 100, 30);
        usernameLabel.setForeground(Color.WHITE);
        loginFrame.add(usernameLabel);
    
        JTextField usernameField = new JTextField();
        usernameField.setBounds(150, 230, 200, 30);
        loginFrame.add(usernameField);
    
        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setBounds(50, 280, 100, 30);
        passwordLabel.setForeground(Color.WHITE);
        loginFrame.add(passwordLabel);
    
        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(150, 280, 200, 30);
        loginFrame.add(passwordField);
    
        // Login Button
        JButton loginButton = new JButton("LOGIN");
        loginButton.setBounds(150, 340, 100, 40);
        loginButton.setBackground(Color.decode("#569fff"));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);
        loginButton.setBorderPainted(false);
    
        // Button hover effect
        loginButton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                loginButton.setBackground(Color.decode("#0069f4"));
            }
    
            public void mouseExited(MouseEvent e) {
                loginButton.setBackground(Color.decode("#569fff"));
            }
        });
    
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Validate user login
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
    
                if (validateLogin(username, password)) {
                    // After successful login, open Main Frame
                    loginFrame.dispose();
                    openMainFrame();
                } else {
                    JOptionPane.showMessageDialog(loginFrame, "Invalid Username or Password");
                }
            }
        });
        loginFrame.add(loginButton);
    
        // Link to registration frame
        JLabel registerLink = new JLabel("<HTML><U>Tidak Punya Akun? Daftar</U></HTML>");
        registerLink.setBounds(130, 400, 150, 30);
        registerLink.setForeground(Color.WHITE);
        registerLink.setCursor(new Cursor(Cursor.HAND_CURSOR));
        registerLink.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                loginFrame.dispose();  // Close login frame
                openRegisterFrame();  // Open registration frame
            }
        });
        loginFrame.add(registerLink);
    
        loginFrame.setVisible(true);
    }    

    // Frame utama untuk aplikasi
    public static void openMainFrame() {
        initConnection();
    // Frame Main
        JFrame mainFrame = new JFrame("Main - Aplikasi Pengelolaan Obat");
        mainFrame.setSize(800, 600);
        mainFrame.getContentPane().setBackground(Color.decode("#388dff"));
        mainFrame.setLayout(null);
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    // Logo
        ImageIcon logoIcon = new ImageIcon("D:\\projekPBO\\pengelolaanobat\\apotek_logoo.png");
        Image logoImage = logoIcon.getImage();
        Image scaledLogo = logoImage.getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        logoIcon = new ImageIcon(scaledLogo);
        JLabel logoLabel = new JLabel(logoIcon);
        logoLabel.setBounds(350, 20, 100, 100);
        mainFrame.add(logoLabel);

    // Title
        JLabel title1 = new JLabel("DATA OBAT APOTEK");
        title1.setBounds(300, 130, 300, 30);
        title1.setFont(new Font("Arial", Font.BOLD, 18));
        title1.setForeground(Color.WHITE);
        mainFrame.add(title1);

        JLabel title2 = new JLabel("TABEL DATA OBAT APOTEK");
        title2.setBounds(260, 160, 300, 30);
        title2.setFont(new Font("Arial", Font.BOLD, 18));
        title2.setForeground(Color.WHITE);
        mainFrame.add(title2);

    // Table
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{"ID", "Nama", "Jumlah", "Harga", "Expired Date"});
    
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(50, 200, 700, 200);
        mainFrame.add(scrollPane);
    
    // Panggil metode untuk memuat data ke tabel
        populateTable(model);

    // Buttons
        JButton tambahButton = new JButton("TAMBAH");
        JButton editButton = new JButton("EDIT");
        JButton hapusButton = new JButton("HAPUS");
        JButton kembaliButton = new JButton("KEMBALI");

        tambahButton.setBounds(150, 450, 100, 40);
        editButton.setBounds(270, 450, 100, 40);
        hapusButton.setBounds(390, 450, 100, 40);
        kembaliButton.setBounds(510, 450, 100, 40);

        mainFrame.add(tambahButton);
        mainFrame.add(editButton);
        mainFrame.add(hapusButton);
        mainFrame.add(kembaliButton);

    // Tombol TAMBAH: Membuka frame tambah data
        tambahButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                openTambahDataFrame();
            }
        });

    // Tombol EDIT: Membuka pop-up konfirmasi edit
        editButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int row = table.getSelectedRow();
                if (row != -1) {
                    String nama = table.getValueAt(row, 1).toString(); // Ambil nama obat
                    int option = JOptionPane.showConfirmDialog(mainFrame,
                            "Apakah Anda yakin ingin mengedit data obat: " + nama + "?",
                            "Konfirmasi Edit",
                            JOptionPane.YES_NO_OPTION);
                    if (option == JOptionPane.YES_OPTION) {
                    // Buka form edit data
                        openEditDataFrame(row);
                    }
                } else {
                    JOptionPane.showMessageDialog(mainFrame, "Pilih data yang ingin diedit terlebih dahulu.");
                }
            }
        });

    // Tombol HAPUS: Pop-up konfirmasi hapus
        hapusButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int row = table.getSelectedRow();
                if (row != -1) {
                    String nama = table.getValueAt(row, 1).toString(); // Ambil nama obat
                    int option = JOptionPane.showConfirmDialog(mainFrame,
                            "Apakah Anda yakin ingin menghapus data obat: " + nama + "?",
                            "Konfirmasi Hapus",
                            JOptionPane.YES_NO_OPTION);
                    if (option == JOptionPane.YES_OPTION) {
                    // Hapus data dari database
                        int obatId = (int) table.getValueAt(row, 0); // Ambil ID obat
                        deleteObat(obatId, nama);
                        }
                    } else {
                    JOptionPane.showMessageDialog(mainFrame, "Pilih data yang ingin dihapus terlebih dahulu.");
                }
            }
        });

    // Tombol KEMBALI: Kembali ke login frame
        kembaliButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mainFrame.dispose();
                openLoginFrame();
            }
        });

        mainFrame.setVisible(true);
    }

// Frame untuk tambah data obat
    public static void openTambahDataFrame() {
        // Frame Tambah Data
        JFrame tambahFrame = new JFrame("Tambah Data Obat");
        tambahFrame.setSize(400, 400);
        tambahFrame.getContentPane().setBackground(Color.decode("#388dff"));
        tambahFrame.setLayout(null);
        tambahFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

    // Logo
        ImageIcon logoIcon = new ImageIcon("D:\\projekPBO\\pengelolaanobat\\apotek_logoo.png");
        Image logoImage = logoIcon.getImage();
        Image scaledLogo = logoImage.getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        logoIcon = new ImageIcon(scaledLogo);
        JLabel logoLabel = new JLabel(logoIcon);
        logoLabel.setBounds(150, 20, 100, 100);
        tambahFrame.add(logoLabel);

    // Title
        JLabel title = new JLabel("TAMBAH DATA OBAT");
        title.setBounds(120, 130, 200, 30);
        title.setFont(new Font("Arial", Font.BOLD, 18));
        title.setForeground(Color.WHITE);
        tambahFrame.add(title);

    // Form Input
        JLabel namaLabel = new JLabel("Nama Obat:");
        namaLabel.setBounds(50, 180, 100, 30);
        JTextField namaField = new JTextField();
        namaField.setBounds(150, 180, 200, 30);

        JLabel jumlahLabel = new JLabel("Jumlah:");
        jumlahLabel.setBounds(50, 220, 100, 30);
        JTextField jumlahField = new JTextField();
        jumlahField.setBounds(150, 220, 200, 30);

        JLabel hargaLabel = new JLabel("Harga:");
        hargaLabel.setBounds(50, 260, 100, 30);
        JTextField hargaField = new JTextField();
        hargaField.setBounds(150, 260, 200, 30);

        JLabel expired_dateLabel = new JLabel("Expired:");
        expired_dateLabel.setBounds(50, 300, 150, 30);
        JTextField expired_dateField = new JTextField();
        expired_dateField.setBounds(150, 300, 200, 30);

        tambahFrame.add(namaLabel);
        tambahFrame.add(namaField);
        tambahFrame.add(jumlahLabel);
        tambahFrame.add(jumlahField);
        tambahFrame.add(hargaLabel);
        tambahFrame.add(hargaField);
        tambahFrame.add(expired_dateLabel);
        tambahFrame.add(expired_dateField);

    // Tombol TAMBAH untuk menyimpan data
        JButton tambahButton = new JButton("TAMBAH");
        tambahButton.setBounds(150, 340, 100, 40);
        tambahFrame.add(tambahButton);

    // Tombol KEMBALI: Kembali ke frame utama
        JButton kembaliButton = new JButton("KEMBALI");
        kembaliButton.setBounds(270, 340, 100, 40);
        tambahFrame.add(kembaliButton);

    // Tombol KEMBALI action listener
        kembaliButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                tambahFrame.dispose();
                openMainFrame();
            }
        });

    // Tombol TAMBAH action listener
        tambahButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nama = namaField.getText();
                String jumlah = jumlahField.getText();
                String harga = hargaField.getText();
                String expired_date = expired_dateField.getText();

                if (!nama.isEmpty() && !jumlah.isEmpty() && !harga.isEmpty() && !expired_date.isEmpty()) {
                    // Simpan data ke database
                    addObat(nama, jumlah, harga, expired_date);
                    JOptionPane.showMessageDialog(tambahFrame, "Data " + nama + " berhasil ditambahkan.");
                    tambahFrame.dispose();
                    openMainFrame();
                } else {
                    JOptionPane.showMessageDialog(tambahFrame, "Input tidak valid.");
                }
            }
        });

        tambahFrame.setVisible(true);
    }

// Method untuk menambahkan data obat ke database
    public static void addObat(String nama, String jumlah, String harga, String expired_date) {
        try {
            String url = "jdbc:mysql://localhost:3306/pengelolaan_apotek";  // Ganti dengan nama database Anda
            String user = "root";  // Ganti dengan username MySQL
            String pass = "";  // Ganti dengan password MySQL
            Connection conn = DriverManager.getConnection(url, user, pass);
            String query = "INSERT INTO obat (nama, jumlah, harga, expired_date) VALUES (?, ?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, nama);
            pst.setString(2, jumlah);
            pst.setString(3, harga);
            pst.setString(4, expired_date);
            pst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void openEditDataFrame(int id) {
        // Frame Edit Data
        JFrame editFrame = new JFrame("Edit Data Obat");
        editFrame.setSize(400, 500);
        editFrame.getContentPane().setBackground(Color.decode("#388dff"));
        editFrame.setLayout(null);
    
        // Gambar Logo
        ImageIcon logoIcon = new ImageIcon("D:\\projekPBO\\pengelolaanobat\\apotek_logoo.png");
        Image logoImage = logoIcon.getImage();
        Image scaledLogo = logoImage.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
        logoIcon = new ImageIcon(scaledLogo);
        JLabel logoLabel = new JLabel(logoIcon);
        logoLabel.setBounds(150, 20, 100, 100);
        editFrame.add(logoLabel);
    
        // Title
        JLabel title = new JLabel("EDIT DATA OBAT");
        title.setBounds(100, 120, 200, 30);
        title.setFont(new Font("Arial", Font.BOLD, 16));
        title.setForeground(Color.WHITE);
        title.setHorizontalAlignment(SwingConstants.CENTER);
        editFrame.add(title);
    
        // Form Input
        JLabel nameLabel = new JLabel("Nama Obat:");
        JTextField nameField = new JTextField();
        JLabel jumlahLabel = new JLabel("Jumlah:");
        JTextField jumlahField = new JTextField();
        JLabel hargaLabel = new JLabel("Harga:");
        JTextField hargaField = new JTextField();
        JLabel expiredLabel = new JLabel("Expired:");
        JTextField expiredField = new JTextField();
    
        nameLabel.setBounds(50, 170, 120, 30);
        nameField.setBounds(180, 170, 150, 30);
        jumlahLabel.setBounds(50, 220, 120, 30);
        jumlahField.setBounds(180, 220, 150, 30);
        hargaLabel.setBounds(50, 270, 120, 30);
        hargaField.setBounds(180, 270, 150, 30);
        expiredLabel.setBounds(50, 320, 120, 30);
        expiredField.setBounds(180, 320, 150, 30);
    
        nameLabel.setForeground(Color.WHITE);
        jumlahLabel.setForeground(Color.WHITE);
        hargaLabel.setForeground(Color.WHITE);
        expiredLabel.setForeground(Color.WHITE);
    
        editFrame.add(nameLabel);
        editFrame.add(nameField);
        editFrame.add(jumlahLabel);
        editFrame.add(jumlahField);
        editFrame.add(hargaLabel);
        editFrame.add(hargaField);
        editFrame.add(expiredLabel);
        editFrame.add(expiredField);
    
        // Tombol
        JButton saveButton = new JButton("SIMPAN");
        JButton backButton = new JButton("KEMBALI");
    
        saveButton.setBounds(100, 400, 80, 30);
        backButton.setBounds(200, 400, 80, 30);
    
        editFrame.add(saveButton);
        editFrame.add(backButton);
    
        // Action untuk tombol SIMPAN
        saveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nama = nameField.getText();
                String jumlah = jumlahField.getText();
                String harga = hargaField.getText();
                String tanggalKadaluarsa = expiredField.getText();
    
                // Validasi input
                if (nama.isEmpty() || jumlah.isEmpty() || harga.isEmpty() || tanggalKadaluarsa.isEmpty()) {
                    JOptionPane.showMessageDialog(editFrame, "Input tidak boleh kosong.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
    
                try {
                    int jumlahInt = Integer.parseInt(jumlah);
                    double hargaDouble = Double.parseDouble(harga);
    
                    // Update database
                    String url = "jdbc:mysql://localhost:3306/pengelolaan_apotek";
                    String user = "root";
                    String pass = "";
    
                    Connection conn = DriverManager.getConnection(url, user, pass);
                    String query = "UPDATE obat SET nama = ?, jumlah = ?, harga = ?, expired_date = ? WHERE id = ?";
                    PreparedStatement pst = conn.prepareStatement(query);
                    pst.setString(1, nama);
                    pst.setInt(2, jumlahInt);
                    pst.setDouble(3, hargaDouble);
                    pst.setString(4, tanggalKadaluarsa);
                    pst.setInt(5, id);
                    pst.executeUpdate();
    
                    JOptionPane.showMessageDialog(editFrame, "Data berhasil diupdate.");
                    editFrame.dispose(); // Tutup frame edit
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(editFrame, "Input jumlah atau harga tidak valid.", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(editFrame, "Terjadi kesalahan pada database.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    
        // Action untuk tombol KEMBALI
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                editFrame.dispose();
            }
        });
    
        editFrame.setVisible(true);
    }

    public static void deleteObat(int id, String nama) {
        try {
            String url = "jdbc:mysql://localhost:3306/pengelolaan_apotek";
            String user = "root";
            String pass = "";
    
            Connection conn = DriverManager.getConnection(url, user, pass);
            String query = "DELETE FROM obat WHERE id = ?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setInt(1, id);
            pst.executeUpdate();
    
            JOptionPane.showMessageDialog(null, "Data \"" + nama + "\" berhasil dihapus.");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan saat menghapus data.");
        }
    }
    
    public static void populateTable(DefaultTableModel model) {
        try {
            model.setRowCount(0); // Hapus data sebelumnya
            String query = "SELECT * FROM obat";
            PreparedStatement pst = conn.prepareStatement(query);
            ResultSet rs = pst.executeQuery();
    
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("nama"),
                    rs.getInt("jumlah"),
                    rs.getDouble("harga"),
                    rs.getDate("expired_date")
                });
            }
    
            rs.close();
            pst.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error memuat data: " + e.getMessage());
        }
    }                

    // Open registration frame
    public static void openRegisterFrame() {
        // Frame Daftar Admin
        JFrame registerFrame = new JFrame("Daftar Admin - Aplikasi Pengelolaan Obat");
        registerFrame.setSize(400, 650); 
        registerFrame.getContentPane().setBackground(Color.decode("#388dff"));
        registerFrame.setLayout(null);
        registerFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
        // Logo
        ImageIcon logoIcon = new ImageIcon("D:\\projekPBO\\pengelolaanobat\\apotek_logoo.png");
        Image logoImage = logoIcon.getImage();
        Image scaledLogo = logoImage.getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        logoIcon = new ImageIcon(scaledLogo);
        JLabel logoLabel = new JLabel(logoIcon);
        logoLabel.setBounds(150, 30, 100, 100);
        registerFrame.add(logoLabel);
    
        // Title
        JLabel title = new JLabel("DAFTAR ADMIN");
        title.setBounds(140, 140, 150, 30);
        title.setFont(new Font("Arial", Font.BOLD, 18));
        title.setForeground(Color.WHITE);
        registerFrame.add(title);
    
        // Username and Password Labels and Fields
        JLabel usernameLabel = new JLabel("Username");
        usernameLabel.setBounds(50, 200, 100, 30);
        usernameLabel.setForeground(Color.WHITE);
        registerFrame.add(usernameLabel);
    
        JTextField usernameField = new JTextField();
        usernameField.setBounds(150, 200, 200, 30);
        registerFrame.add(usernameField);
    
        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setBounds(50, 250, 100, 30);
        passwordLabel.setForeground(Color.WHITE);
        registerFrame.add(passwordLabel);
    
        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(150, 250, 200, 30);
        registerFrame.add(passwordField);
    
        // Register Button
        JButton registerButton = new JButton("DAFTAR");
        registerButton.setBounds(150, 310, 100, 40);
        registerButton.setBackground(Color.decode("#569fff"));
        registerButton.setForeground(Color.WHITE);
        registerButton.setFocusPainted(false);
        registerButton.setBorderPainted(false);
    
        registerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Process registration
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                registerAdmin(username, password);
            }
        });
        registerFrame.add(registerButton);
    
        // Back Button
        JButton backButton = new JButton("KEMBALI");
        backButton.setBounds(150, 370, 100, 40);
        backButton.setBackground(Color.decode("#569fff"));
        backButton.setForeground(Color.WHITE);
        backButton.setFocusPainted(false);
        backButton.setBorderPainted(false);
    
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Close the register frame and open login frame
                registerFrame.dispose();
                openLoginFrame();  // Kembali ke frame login
            }
        });
        registerFrame.add(backButton);
    
        registerFrame.setVisible(true);
    }    

    // Method to register admin
    public static void registerAdmin(String username, String password) {
        try {
            String url = "jdbc:mysql://localhost:3306/pengelolaan_apotek";  // Ganti dengan nama database Anda
            String user = "root";  // Ganti dengan username MySQL Anda
            String pass = "";  // Ganti dengan password MySQL Anda

            Connection conn = DriverManager.getConnection(url, user, pass);
            String query = "INSERT INTO admin (username, password) VALUES (?, ?)";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, username);
            pst.setString(2, password);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Registrasi Berhasil!");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Registrasi Gagal!");
        }
    }
}